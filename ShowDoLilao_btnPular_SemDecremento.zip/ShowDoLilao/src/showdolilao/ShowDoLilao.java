
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package showdolilao;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author lilau
 */
public class ShowDoLilao extends Application {

    @Override
    public void start(Stage primaryStage) {        
                
        Button btn = new Button();
        btn.setText(" IFBA Campus Ilhéus\n   PROJETO JAVA\n     Profª Karine\n         STI 31 \n  Carlos Martinez\n    Jackson Silva\n     Marcos Paz\n\n>CLIQUE PARA VER<\n\n");
        btn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                System.out.println("PROJETO JAVA__SHOW_DO_LILÃO"); 
                main ab = new main();
                ab.setVisible(true);
                this.dispose();
            }

            private void dispose() {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });

        StackPane root = new StackPane();
        root.getChildren().add(btn);

        Scene scene = new Scene(root, 250, 300);

        primaryStage.setTitle("PROJETO JAVA");
        primaryStage.setScene(scene);
        primaryStage.show();
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    private javafx.scene.text.Font Font(String tahoma, int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
